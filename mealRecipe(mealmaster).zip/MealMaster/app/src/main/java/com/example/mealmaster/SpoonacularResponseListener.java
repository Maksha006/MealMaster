package com.example.mealmaster;

public interface SpoonacularResponseListener {
        void didFetch(RandomSpoonacularResponse response, String message);
        void didError(String message);
}


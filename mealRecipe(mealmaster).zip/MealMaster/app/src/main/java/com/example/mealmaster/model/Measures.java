package com.example.mealmaster.model;

public class Measures {

    public Us us;
    public Metric metric;

}

package com.example.mealmaster.model;

public class Length {

    public int number;
    public String unit;

}

package com.example.mealmaster;

public class SpoonacularRequest {


}

package com.example.mealmaster;

import com.example.mealmaster.model.Recipe;
import com.example.mealmaster.model.Recipe;

import java.util.ArrayList;

public class RandomSpoonacularResponse {

    public ArrayList<Recipe> recipes;
}

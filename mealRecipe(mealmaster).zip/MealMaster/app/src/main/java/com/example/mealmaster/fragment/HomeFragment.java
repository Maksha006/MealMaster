package com.example.mealmaster.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mealmaster.Adapter.RandomSliderAdapter;
import com.example.mealmaster.R;
import com.example.mealmaster.RandomSpoonacularResponse;
import com.example.mealmaster.SpoonacularManager;
import com.example.mealmaster.SpoonacularResponseListener;
import com.example.mealmaster.model.Recipe;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements SharedPreferences.OnSharedPreferenceChangeListener {

    private Context mContext;
    private View rootView;

    private String getString;
    SeekBar seekBar1,seekBar2;
    TextView Option1,Option2;
    TextView percent1,percent2;
    double count1 = 1 ,count2 = 1;
    boolean flag1 = true, flag2 = true;

    private final String API_KEY = "af3b71ca41664ff586770e97ce55e795";

    private SliderView sliderView;
    private RandomSliderAdapter imageSliderAdapter;

    ProgressDialog dialog;
    SpoonacularManager manager;

    private static final String SHARED_PREFERENCES_NAME = "MySharedPreferences";

    private static final String SEEK_BAR_1_KEY = "seekBar1";
    private static final String SEEK_BAR_2_KEY = "seekBar2";

    private List<Recipe> recipeList = new ArrayList<>();

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mContext = context;
    }

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_home, container, false);

        dialog = new ProgressDialog(mContext);
        dialog.setTitle("Loading...");

        manager = new SpoonacularManager(mContext);
        manager.getSpoonacularApi(spoonacularResponseListener);
        dialog.show();


       //Assign variable du seekbar
        seekBar1 = rootView.findViewById(R.id.seek_bar1);
        seekBar2 = rootView.findViewById(R.id.seek_bar2);

        //Assign variable des Options
        Option1 = rootView.findViewById(R.id.option1);
        Option2 = rootView.findViewById(R.id.option2);

        //Assign variable des pourcentages
        percent1 = rootView.findViewById(R.id.percent1);
        percent2 = rootView.findViewById(R.id.percent2);

        // obtenir une instance of SharedPreferences
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());

        seekBar1.setProgress(sharedPreferences.getInt("seekBar1Value", 0));
        seekBar2.setProgress(sharedPreferences.getInt("seekBar2Value", 0));

        seekBar1.setOnSeekBarChangeListener(seekBarChangeListener);
        seekBar2.setOnSeekBarChangeListener(seekBarChangeListener);



        seekBar1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        Option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // check the Options
                if (flag1){
                    count1++;
                    count2 = 1;
                    flag1 = false;
                    flag2 = true;
                    // calculate percentage
                    calculatePercent();
                }
            }
        });

        seekBar2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        });

        Option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // check the Options
                if (flag1){
                    count1 = 1;
                    count2 ++;
                    flag1 = true;
                    flag2 = false;
                    // calculate percentage
                    calculatePercent();
                }
            }
        });
        return rootView;
    }

    private SpoonacularResponseListener spoonacularResponseListener = new SpoonacularResponseListener() {
        @Override
        public void didFetch(RandomSpoonacularResponse response, String message) {
            dialog.dismiss();
            sliderView = rootView.findViewById(R.id.image_slider);
            imageSliderAdapter = new RandomSliderAdapter(mContext,response.recipes);
            sliderView.setSliderAdapter(imageSliderAdapter);
        }

        @Override
        public void didError(String message) {
            Toast.makeText(mContext,message, Toast.LENGTH_SHORT);
        }
    };

    private void calculatePercent() {

        double total = count1 + count2;
        double recipePercent1 = (count1/total)*100;
        double recipePercent2 = (count2/total)*100;

        percent1.setText(String.format("%.2f",recipePercent1));
        seekBar1.setProgress((int) recipePercent1);

        percent2.setText(String.format("%.2f",recipePercent2));
        seekBar2.setProgress((int) recipePercent2);
    }

    private SeekBar.OnSeekBarChangeListener seekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (seekBar.getId() == R.id.seek_bar1) {
                editor.putInt("seekBar1Value", progress);
            } else if (seekBar.getId() == R.id.seek_bar2) {
                editor.putInt("seekBar2Value", progress);
            }
            editor.apply();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {}

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {}
    };

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("METAPX","onDestroy is CALLED");
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        if (s.equals("seekBar1Value")) {
            SeekBar seekBar1 = rootView.findViewById(R.id.seek_bar1);
            seekBar1.setProgress(sharedPreferences.getInt(s, 0));
        } else if (s.equals("seekBar2Value")) {
            SeekBar seekBar2 = rootView.findViewById(R.id.seek_bar2);
            seekBar2.setProgress(sharedPreferences.getInt(s, 0));
        }
    }
}
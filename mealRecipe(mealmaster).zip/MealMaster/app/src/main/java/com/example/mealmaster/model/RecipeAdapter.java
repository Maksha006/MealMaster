package com.example.mealmaster.model;

public class RecipeAdapter {
}
